#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    char buffer[BUFFER_SIZE] = {0};
    double balance = 0.0;  // Bank account balance

    // 1. Create socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // 2. Bind socket to IP/Port
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY; // Listen on all interfaces
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // 3. Listen for connections
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    printf("Server started. Waiting for connections on port %d...\n", PORT);

    // 4. Accept a client connection
    if ((new_socket = accept(server_fd, (struct sockaddr *)&address,
                             (socklen_t*)&addrlen)) < 0) {
        perror("Accept failed");
        exit(EXIT_FAILURE);
    }

    printf("Client connected.\n");

    // 5. Communication loop
    while (1) {
        memset(buffer, 0, BUFFER_SIZE);
        int valread = read(new_socket, buffer, BUFFER_SIZE);
        if (valread <= 0) break; // Client disconnected

        buffer[strcspn(buffer, "\n")] = 0; // Remove newline

        if (strcasecmp(buffer, "BALANCE") == 0) {
            char response[BUFFER_SIZE];
            snprintf(response, BUFFER_SIZE, "Current balance: %.2f\n", balance);
            send(new_socket, response, strlen(response), 0);

        } else if (strncasecmp(buffer, "DEPOSIT ", 8) == 0) {
            double amount = atof(buffer + 8);
            if (amount > 0) {
                balance += amount;
                char response[BUFFER_SIZE];
                snprintf(response, BUFFER_SIZE,
                         "Deposit successful. New balance: %.2f\n", balance);
                send(new_socket, response, strlen(response), 0);
            } else {
                send(new_socket, "Invalid deposit amount.\n", 25, 0);
            }

        } else if (strncasecmp(buffer, "WITHDRAW ", 9) == 0) {
            double amount = atof(buffer + 9);
            if (amount > 0 && amount <= balance) {
                balance -= amount;
                char response[BUFFER_SIZE];
                snprintf(response, BUFFER_SIZE,
                         "Withdrawal successful. New balance: %.2f\n", balance);
                send(new_socket, response, strlen(response), 0);
            } else {
                send(new_socket, "Invalid withdrawal amount or insufficient funds.\n", 50, 0);
            }

        } else if (strcasecmp(buffer, "EXIT") == 0) {
            send(new_socket, "Goodbye!\n", 9, 0);
            break;

        } else {
            send(new_socket, "Unknown command.\n", 17, 0);
        }
    }

    close(new_socket);
    close(server_fd);
    printf("Server closed.\n");
    return 0;
}
